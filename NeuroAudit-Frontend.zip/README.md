# NeuroAudit

Frontend for the **AI-Powered Neural Data Privacy Risk Assessment** platform. This repository contains the React interface only. Demonstration scores and EEG traces are mock data; analysis, storage, and report export are intended for a separate backend.

## Stack

React, TypeScript, Vite, Tailwind CSS, React Router, Lucide React, Recharts.

## Run

```bash
npm install
npm run dev
```

Build: `npm run build`

## Flow

Home → New Audit → Scan → Dashboard → Privacy Assessment → Recommendations → Report

The dashboard and other result pages are available only after the demonstration scan completes.
