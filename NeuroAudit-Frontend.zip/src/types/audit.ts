export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH'

export type Priority = 'HIGH' | 'MEDIUM' | 'LOW'

export type RiskDimensionKey = 'identity' | 'emotion' | 'stress' | 'workload'

export interface RiskDimension {
  key: RiskDimensionKey
  label: string
  score: number
  level: RiskLevel
  summary: string
  explanation: string
  concern: string
}

export interface Recommendation {
  id: string
  number: string
  title: string
  priority: Priority
  why: string
  action: string
}

export interface RecentAudit {
  id: string
  name: string
  date: string
  fileName: string
  risk: number
  level: RiskLevel
  status: string
}

export interface AuditRecord {
  auditName: string
  fileName: string
  analysisDate: string
  status: string
  overallRisk: number
  riskLevel: RiskLevel
  overallSummary: string
  executiveSummary: string
  keyFindings: string[]
  dimensions: RiskDimension[]
  recommendations: Recommendation[]
  recentAudits: RecentAudit[]
  disclaimer: string
}

export interface UploadedFileMeta {
  name: string
  size: number
  type: string
}
