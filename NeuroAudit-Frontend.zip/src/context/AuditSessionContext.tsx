import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react'
import { MOCK_AUDIT } from '../data/mockAudit'
import type { AuditRecord, UploadedFileMeta } from '../types/audit'

interface AuditSessionContextValue {
  auditName: string
  description: string
  file: UploadedFileMeta | null
  scanComplete: boolean
  analysisDate: string
  setAuditName: (value: string) => void
  setDescription: (value: string) => void
  setFile: (file: UploadedFileMeta | null) => void
  completeScan: () => void
  resetScan: () => void
}

const AuditSessionContext = createContext<AuditSessionContextValue | null>(null)

function formatToday() {
  return new Intl.DateTimeFormat('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date())
}

export function AuditSessionProvider({ children }: { children: ReactNode }) {
  const [auditName, setAuditName] = useState('Clinical cohort session A')
  const [description, setDescription] = useState('')
  const [file, setFile] = useState<UploadedFileMeta | null>(null)
  const [scanComplete, setScanComplete] = useState(false)
  const [analysisDate, setAnalysisDate] = useState(MOCK_AUDIT.analysisDate)

  const completeScan = useCallback(() => {
    setScanComplete(true)
    setAnalysisDate(formatToday())
  }, [])

  const resetScan = useCallback(() => {
    setScanComplete(false)
  }, [])

  const value = useMemo(
    () => ({
      auditName,
      description,
      file,
      scanComplete,
      analysisDate,
      setAuditName,
      setDescription,
      setFile,
      completeScan,
      resetScan,
    }),
    [auditName, description, file, scanComplete, analysisDate, completeScan, resetScan],
  )

  return <AuditSessionContext.Provider value={value}>{children}</AuditSessionContext.Provider>
}

export function useAuditSession() {
  const ctx = useContext(AuditSessionContext)
  if (!ctx) throw new Error('useAuditSession must be used within AuditSessionProvider')
  return ctx
}

/** Presentation data: centralized mock record with session overlay. Replace this seam later with API data. */
export function useAudit(): AuditRecord & { description: string } {
  const session = useAuditSession()
  return {
    ...MOCK_AUDIT,
    auditName: session.auditName.trim() || MOCK_AUDIT.auditName,
    fileName: session.file?.name || MOCK_AUDIT.fileName,
    analysisDate: session.scanComplete ? session.analysisDate : MOCK_AUDIT.analysisDate,
    description: session.description,
  }
}
