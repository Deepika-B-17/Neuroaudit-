import { useNavigate } from 'react-router-dom'
import { FileText } from 'lucide-react'
import { UploadZone } from '../components/upload/UploadZone'
import { Button } from '../components/ui/Button'
import { Card } from '../components/ui/Card'
import { useAuditSession } from '../context/AuditSessionContext'
import { formatFileSize } from '../lib/cn'

export function NewAudit() {
  const navigate = useNavigate()
  const { auditName, description, file, setAuditName, setDescription, setFile, resetScan } = useAuditSession()

  return (
    <div className="mx-auto max-w-3xl px-5 py-12">
      <p className="text-[11px] font-semibold tracking-[0.18em] uppercase text-muted">New audit</p>
      <h1 className="mt-2 text-3xl font-bold tracking-tight">Start a New Privacy Audit</h1>
      <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted">
        Upload an EEG recording to begin the neural-data privacy assessment.
      </p>

      <Card elevated className="mt-8 p-6">
        <h2 className="text-sm font-semibold">Audit information</h2>
        <div className="mt-4 grid gap-4">
          <label className="block text-sm">
            <span className="mb-1.5 block text-muted">Audit name</span>
            <input
              value={auditName}
              onChange={(e) => setAuditName(e.target.value)}
              className="w-full rounded-na border border-border bg-background px-3 py-2.5 text-sm text-foreground"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1.5 block text-muted">Description (optional)</span>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full resize-y rounded-na border border-border bg-background px-3 py-2.5 text-sm text-foreground"
              placeholder="Study context, protocol, or notes for this audit"
            />
          </label>
        </div>
      </Card>

      <div className="mt-6">
        {!file ? (
          <UploadZone
            onFile={(selected) => {
              resetScan()
              setFile({
                name: selected.name,
                size: selected.size,
                type: selected.type || selected.name.split('.').pop()?.toUpperCase() || 'EEG',
              })
            }}
          />
        ) : (
          <Card elevated className="p-5">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-start gap-3">
                <span className="flex h-10 w-10 items-center justify-center rounded-na bg-accent-soft text-accent">
                  <FileText size={18} aria-hidden />
                </span>
                <div>
                  <p className="font-semibold">{file.name}</p>
                  <p className="mt-1 text-sm text-muted">
                    {formatFileSize(file.size)} · {file.type || 'EEG'} · Ready to analyze
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="danger"
                  onClick={() => {
                    setFile(null)
                    resetScan()
                  }}
                >
                  Remove
                </Button>
                <Button
                  onClick={() => {
                    resetScan()
                    navigate('/audit/scan')
                  }}
                >
                  Analyze EEG →
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
