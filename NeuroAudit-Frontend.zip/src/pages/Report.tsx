import { ReportPreview } from '../components/report/ReportPreview'
import { Button } from '../components/ui/Button'
import { useToast } from '../components/ui/Toast'

export function Report() {
  const { notify } = useToast()

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Privacy Risk Assessment Report</h1>
          <p className="mt-1 text-sm text-muted">Demonstration report layout. Export actions will connect to the audit backend.</p>
        </div>
        <div className="no-print flex flex-wrap gap-2">
          <Button
            onClick={() => notify('PDF generation will be connected to the audit backend.')}
          >
            Generate PDF
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              notify('Print is available in the browser. Full report export will be connected to the audit backend.')
              window.print()
            }}
          >
            Print Report
          </Button>
          <Button
            variant="secondary"
            onClick={() => notify('Sharing will be connected to the audit backend.')}
          >
            Share Report
          </Button>
        </div>
      </div>
      <ReportPreview />
    </div>
  )
}
