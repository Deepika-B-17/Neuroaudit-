import { useEffect } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { EEGChart } from '../components/eeg/EEGChart'
import { ProgressStepper } from '../components/scan/ProgressStepper'
import { Button } from '../components/ui/Button'
import { Card } from '../components/ui/Card'
import { useAuditSession } from '../context/AuditSessionContext'
import { useScanProgress } from '../hooks/useScanProgress'
import { formatFileSize } from '../lib/cn'

export function Scan() {
  const navigate = useNavigate()
  const { file, completeScan } = useAuditSession()
  const { stepIndex, progress, complete, currentStage } = useScanProgress(Boolean(file))

  useEffect(() => {
    if (complete) completeScan()
  }, [complete, completeScan])

  if (!file) {
    return <Navigate to="/audit/new" replace />
  }

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <p className="text-[11px] font-semibold tracking-[0.18em] uppercase text-muted">Analysis</p>
      <h1 className="mt-2 text-3xl font-bold tracking-tight">Analyzing EEG Data</h1>
      <p className="mt-2 text-sm text-muted">
        Demonstration progress for {file.name} ({formatFileSize(file.size)}). This visualization is not live signal processing.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_280px]">
        <Card elevated className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="text-xs font-semibold tracking-[0.14em] uppercase text-muted">EEG Signal</p>
            <p className="text-xs text-muted">{file.name}</p>
          </div>
          <EEGChart animated height={340} />
        </Card>

        <div className="space-y-6">
          <Card className="p-5">
            <p className="text-xs font-semibold tracking-[0.14em] uppercase text-muted">Status</p>
            <p className="mt-2 text-sm font-semibold">{complete ? 'Analysis complete' : currentStage}</p>
            <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-border">
              <div
                className="h-full rounded-full bg-accent transition-[width] duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="mt-2 text-sm text-muted">
              {progress}% · {complete ? 'Complete' : 'Estimated status: analysis running'}
            </p>
          </Card>
          <Card className="p-5">
            <ProgressStepper stepIndex={stepIndex} complete={complete} />
          </Card>
          {complete && (
            <div>
              <p className="mb-3 text-sm font-semibold">Analysis Complete</p>
              <Button className="w-full" onClick={() => navigate('/app/dashboard')}>
                View Privacy Dashboard →
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
